﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AquaVM
{
    public class DropdownVM
    {
        public string Module { get; set; }
        public List<ConfigVM> DropDown { get; set; }
    }
}
